<?php
/**
 * Unified sacramental records index.
 *
 * This page is a compact discovery workspace. Existing sacrament pages remain
 * the edit surfaces so their detailed validation and register-specific forms
 * stay unchanged.
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/sacrament-data.php';
require_once __DIR__ . '/../../includes/record-search.php';
require_role('secretary');

$basePath = base_path();

// This page's own app-relative URL (path + current query string) so the record
// view can send the user back here with the same search, filter and page.
$selfReturn = '/admin/records/index.php' . ((($_SERVER['QUERY_STRING'] ?? '') !== '') ? '?' . $_SERVER['QUERY_STRING'] : '');
$pageTitle = 'All Records';
$search = trim((string) ($_GET['q'] ?? ''));
$type = (string) ($_GET['type'] ?? '');
$allowedTypes = ['baptismal', 'confirmation', 'first_communion', 'marriage'];
if (!in_array($type, $allowedTypes, true)) {
    $type = '';
}
$fromYear = preg_match('/^\d{4}$/', (string) ($_GET['from'] ?? '')) ? (int) $_GET['from'] : null;
$toYear = preg_match('/^\d{4}$/', (string) ($_GET['to'] ?? '')) ? (int) $_GET['to'] : null;
$perPage = (int) ($_GET['per_page'] ?? 25);
if (!in_array($perPage, [10, 25, 50], true)) {
    $perPage = 25;
}
$page = max(1, (int) ($_GET['page'] ?? 1));
$added = isset($_GET['added']);
$updated = isset($_GET['updated']);
$nochange = isset($_GET['nochange']);
$shifted = isset($_GET['shifted']) ? (int) $_GET['shifted'] : 0;
$completedApp = trim((string) ($_GET['completed_app'] ?? ''));
$sort = (string) ($_GET['sort'] ?? 'date_desc');
$allowedSorts = ['book', 'book_desc', 'page', 'page_desc', 'line', 'line_desc', 'name', 'name_desc', 'date_desc', 'date_asc', 'sacrament'];
if (!in_array($sort, $allowedSorts, true)) {
    $sort = 'date_desc';
}

$recordSql = <<<'SQL'
SELECT CASE sr.sacrament_type
           WHEN 'baptism' THEN 'baptismal'
           ELSE sr.sacrament_type
       END AS record_type,
       sr.id,
       CONCAT_WS(' ', p.first_name, p.middle_name, p.last_name, p.suffix) AS record_name,
       CONCAT_WS(' ', spouse.first_name, spouse.middle_name, spouse.last_name, spouse.suffix) AS spouse_name,
       sr.event_date, sr.entry_no, sr.book_no, sr.page_no, sr.line_no,
       sr.person_id, sr.spouse_person_id,
       p.first_name AS record_first_name,
       p.middle_name AS record_middle_name,
       p.last_name AS record_last_name,
       p.suffix AS record_suffix,
       spouse.first_name AS spouse_first_name,
       spouse.middle_name AS spouse_middle_name,
       spouse.last_name AS spouse_last_name,
       spouse.suffix AS spouse_suffix
  FROM sacrament_records sr
  JOIN persons p ON p.id = sr.person_id
  LEFT JOIN persons spouse ON spouse.id = sr.spouse_person_id
SQL;

$where = [];
$params = [];
if ($search !== '') {
    $reference = unified_record_search_reference($search);
    if ($reference !== null) {
        foreach ($reference as $field => $value) {
            if ($field === 'book_no') {
                $bookValues = unified_record_search_book_values($value);
                $where[] = "UPPER(TRIM(COALESCE({$field}, ''))) IN (" . implode(', ', array_fill(0, count($bookValues), 'UPPER(?)')) . ')';
                array_push($params, ...$bookValues);
            } else {
                $where[] = "UPPER(TRIM(COALESCE({$field}, ''))) = UPPER(?)";
                $params[] = $value;
            }
        }
    } else {
        $nameTokens = array_slice(preg_split('/[\s,]+/', $search, -1, PREG_SPLIT_NO_EMPTY), 0, 5);
        $nameTokenConditions = [];
        $nameTokenParams = [];
        foreach ($nameTokens as $token) {
            $nameTokenLike = '%' . addcslashes($token, '\\_%') . '%';
            $middleInitial = search_middle_initial($token);
            $nameTokenConditions[] = '(record_name LIKE ? OR spouse_name LIKE ?'
                . ($middleInitial !== null
                    ? " OR UPPER(LEFT(COALESCE(record_middle_name, ''), 1)) = UPPER(?)"
                        . " OR UPPER(LEFT(COALESCE(spouse_middle_name, ''), 1)) = UPPER(?)"
                    : '')
                . ')';
            array_push($nameTokenParams, $nameTokenLike, $nameTokenLike);
            if ($middleInitial !== null) {
                $nameTokenParams[] = $middleInitial;
                $nameTokenParams[] = $middleInitial;
            }
        }
        $where[] = '(record_name LIKE ? OR spouse_name LIKE ? OR CAST(id AS CHAR) LIKE ? OR book_no LIKE ? OR page_no LIKE ? OR line_no LIKE ?'
            . ($nameTokenConditions ? ' OR (' . implode(' AND ', $nameTokenConditions) . ')' : '')
            . ')';
        $fullSearchLike = '%' . addcslashes($search, '\\_%') . '%';
        array_push($params, $fullSearchLike, $fullSearchLike, $fullSearchLike, $fullSearchLike, $fullSearchLike, $fullSearchLike);
        array_push($params, ...$nameTokenParams);
    }
}
if ($type !== '') {
    $where[] = 'record_type = ?';
    $params[] = $type;
}
if ($fromYear !== null) {
    $where[] = 'YEAR(event_date) >= ?';
    $params[] = $fromYear;
}
if ($toYear !== null) {
    $where[] = 'YEAR(event_date) <= ?';
    $params[] = $toYear;
}
$whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';

$countStmt = $pdo->prepare("SELECT COUNT(*) FROM ({$recordSql}) AS records{$whereSql}");
$countStmt->execute($params);
$totalRows = (int) $countStmt->fetchColumn();
$totalPages = max(1, (int) ceil($totalRows / $perPage));
$page = min($page, $totalPages);
$offset = ($page - 1) * $perPage;

$orderClauses = [
    'book'       => "CAST(COALESCE(NULLIF(book_no, ''), '0') AS UNSIGNED) ASC, CAST(COALESCE(NULLIF(page_no, ''), '0') AS UNSIGNED) ASC, CAST(COALESCE(NULLIF(line_no, ''), '0') AS UNSIGNED) ASC",
    'book_desc'  => "CAST(COALESCE(NULLIF(book_no, ''), '0') AS UNSIGNED) DESC, CAST(COALESCE(NULLIF(page_no, ''), '0') AS UNSIGNED) DESC, CAST(COALESCE(NULLIF(line_no, ''), '0') AS UNSIGNED) DESC",
    'page'       => "CAST(COALESCE(NULLIF(page_no, ''), '0') AS UNSIGNED) ASC, CAST(COALESCE(NULLIF(book_no, ''), '0') AS UNSIGNED) ASC, CAST(COALESCE(NULLIF(line_no, ''), '0') AS UNSIGNED) ASC",
    'page_desc'  => "CAST(COALESCE(NULLIF(page_no, ''), '0') AS UNSIGNED) DESC, CAST(COALESCE(NULLIF(book_no, ''), '0') AS UNSIGNED) DESC, CAST(COALESCE(NULLIF(line_no, ''), '0') AS UNSIGNED) DESC",
    'line'       => "CAST(COALESCE(NULLIF(line_no, ''), '0') AS UNSIGNED) ASC, CAST(COALESCE(NULLIF(book_no, ''), '0') AS UNSIGNED) ASC, CAST(COALESCE(NULLIF(page_no, ''), '0') AS UNSIGNED) ASC",
    'line_desc'  => "CAST(COALESCE(NULLIF(line_no, ''), '0') AS UNSIGNED) DESC, CAST(COALESCE(NULLIF(book_no, ''), '0') AS UNSIGNED) DESC, CAST(COALESCE(NULLIF(page_no, ''), '0') AS UNSIGNED) DESC",
    'name'       => 'record_name ASC',
    'name_desc'  => 'record_name DESC',
    'date_desc'  => 'event_date DESC, record_name ASC',
    'date_asc'   => 'event_date ASC, record_name ASC',
    'sacrament'  => 'record_type ASC, record_name ASC',
];
$listStmt = $pdo->prepare(
    "SELECT * FROM ({$recordSql}) AS records{$whereSql}
     ORDER BY {$orderClauses[$sort]} LIMIT {$perPage} OFFSET {$offset}"
);
$listStmt->execute($params);
$records = $listStmt->fetchAll();

$labels = [
    'baptismal' => 'Baptismal',
    'confirmation' => 'Confirmation',
    'first_communion' => 'First Communion',
    'marriage' => 'Marriage',
];
function unified_records_url(array $overrides = []): string
{
    global $basePath, $search, $type, $fromYear, $toYear, $perPage, $sort;
    $query = array_filter([
        'q' => $search,
        'type' => $type,
        'from' => $fromYear,
        'to' => $toYear,
        'per_page' => $perPage === 25 ? null : $perPage,
        'sort' => $sort === 'date_desc' ? null : $sort,
    ], static fn ($value) => $value !== null && $value !== '');
    foreach ($overrides as $key => $value) {
        if ($value === null || $value === '') {
            unset($query[$key]);
        } else {
            $query[$key] = $value;
        }
    }
    $queryString = http_build_query($query);
    return $basePath . '/admin/records/index.php' . ($queryString !== '' ? '?' . e($queryString) : '');
}

function unified_sort_url(string $key): string
{
    global $sort;
    if ($key === 'date_desc' || $key === 'date_asc') {
        $next = $sort === 'date_desc' ? 'date_asc' : 'date_desc';
    } else {
        $next = $sort === $key ? $key . '_desc' : $key;
        if ($sort === $key . '_desc') {
            $next = $key;
        }
    }
    return unified_records_url(['sort' => $next, 'page' => null]);
}

function unified_sort_indicator(string $key): string
{
    global $sort;
    if ($key === 'date_desc' || $key === 'date_asc') {
        $direction = $sort === 'date_desc' ? 'desc' : ($sort === 'date_asc' ? 'asc' : null);
    } else {
        $direction = $sort === $key ? 'asc' : ($sort === $key . '_desc' ? 'desc' : null);
    }
    if ($direction === 'asc') {
        return ' <span class="sort-indicator" aria-hidden="true">↑</span>';
    }
    if ($direction === 'desc') {
        return ' <span class="sort-indicator" aria-hidden="true">↓</span>';
    }
    return ' <span class="sort-indicator sort-indicator-muted" aria-hidden="true">↕</span>';
}

require_once __DIR__ . '/../../includes/admin-header.php';
?>
        <?php if ($added): ?><div class="alert alert-success"><p>Record added.<?php if ($shifted > 0): ?> (<?= $shifted ?> later entries shifted.)<?php endif; ?><?php if ($completedApp !== ''): ?> Application <?= e($completedApp) ?> completed.<?php endif; ?></p></div><?php endif; ?>
    <?php if ($updated): ?><div class="alert alert-success"><p>Record updated.<?php if ($shifted > 0): ?> (<?= $shifted ?> later entries shifted.)<?php endif; ?></p></div><?php endif; ?>
    <?php if ($nochange): ?><div class="alert alert-info"><p>No changes were made.</p></div><?php endif; ?>

    <div class="page-heading">
            <div>
                <p class="hero-eyebrow">Register index</p>
                <h1>Sacramental Register Records</h1>
                <p class="field-hint">These are completed sacrament entries already recorded in the parish register. Certificate requests and walk-in requests are managed separately.</p>
<?php
$editorTypeByRecordType = [
    'baptismal' => 'baptism',
    'confirmation' => 'confirmation',
    'first_communion' => 'first_communion',
    'marriage' => 'marriage',
];
?>
<details style="display:inline-block;position:relative;margin-left:1rem;">
    <summary class="btn btn-success btn-small" style="cursor:pointer;">+ Add record</summary>
    <div style="position:absolute;z-index:10;background:#fff;border:1px solid #ccc;padding:.5rem;margin-top:.25rem;min-width:12rem;">
        <?php foreach ($editorTypeByRecordType as $rt => $editorType): ?>
            <a class="btn btn-small" style="display:block;margin:.25rem 0;" href="<?= e($basePath . '/admin/records/editor.php?' . http_build_query(['type' => $editorType, 'new' => 1])) ?>"><?= e($labels[$rt] ?? ucfirst($rt)) ?></a>
        <?php endforeach; ?>
    </div>
</details>
            </div>
        </div>
        <p class="field-hint">Search names (words can be in any order), record IDs, or an exact register reference such as <code>b12 p1 l4</code>. You can also search one field, such as <code>p1</code> or <code>l4</code>; then open the register-specific editor to verify the physical logbook reference.</p>

        <div class="record-type-chips">
<?php foreach (['' => 'All', 'baptismal' => 'Baptism', 'confirmation' => 'Confirmation', 'first_communion' => 'First Communion', 'marriage' => 'Marriage'] as $chipValue => $chipLabel): ?>
            <a class="record-type-chip<?= $type === $chipValue ? ' active' : '' ?>" href="<?= e(unified_records_url(['type' => $chipValue === '' ? null : $chipValue, 'page' => null])) ?>"><?= e($chipLabel) ?></a>
<?php endforeach; ?>
        </div>

        <div class="record-filter-bar">
            <form method="get" action="<?= e($basePath . '/admin/records/index.php') ?>" class="search-form" autocomplete="off">
                <?php if ($type !== ''): ?><input type="hidden" name="type" value="<?= e($type) ?>"><?php endif; ?>
                <?php if ($fromYear !== null): ?><input type="hidden" name="from" value="<?= (int) $fromYear ?>"><?php endif; ?>
                <?php if ($toYear !== null): ?><input type="hidden" name="to" value="<?= (int) $toYear ?>"><?php endif; ?>
                <?php if ($perPage !== 25): ?><input type="hidden" name="per_page" value="<?= (int) $perPage ?>"><?php endif; ?>
                <?php if ($sort !== 'date_desc'): ?><input type="hidden" name="sort" value="<?= e($sort) ?>"><?php endif; ?>
                <input autocomplete="off" type="search" name="q" value="<?= e($search) ?>" placeholder="Name, record ID, or register reference (e.g. b12 p1 l4)">
                <button type="submit" class="btn btn-small">Search</button>
                <?php if ($search !== ''): ?><a class="btn btn-secondary btn-small" href="<?= e(unified_records_url(['q' => null, 'page' => null])) ?>">Clear</a><?php endif; ?>
            </form>

            <form method="get" action="<?= e($basePath . '/admin/records/index.php') ?>" class="per-page-form" autocomplete="off">
                <?php if ($search !== ''): ?><input type="hidden" name="q" value="<?= e($search) ?>"><?php endif; ?>
                <?php if ($type !== ''): ?><input type="hidden" name="type" value="<?= e($type) ?>"><?php endif; ?>
                <?php if ($fromYear !== null): ?><input type="hidden" name="from" value="<?= (int) $fromYear ?>"><?php endif; ?>
                <?php if ($toYear !== null): ?><input type="hidden" name="to" value="<?= (int) $toYear ?>"><?php endif; ?>
                <?php if ($sort !== 'date_desc'): ?><input type="hidden" name="sort" value="<?= e($sort) ?>"><?php endif; ?>
                <label>Show
                    <select name="per_page" onchange="this.form.submit()">
                        <?php foreach ([10, 25, 50] as $choice): ?>
                            <option value="<?= (int) $choice ?>" <?= $perPage === $choice ? 'selected' : '' ?>><?= (int) $choice ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
            </form>
        </div>

        <?php if (isset($_GET['archived'])): ?><p class="alert alert-success">Record archived. It no longer appears in active lists.</p><?php endif; ?>
        <div class="record-workspace-summary">
            <strong><?= number_format($totalRows) ?></strong> record<?= $totalRows === 1 ? '' : 's' ?> found
            <?php if ($totalRows > 0): ?>
                <span>Page <?= (int) $page ?> of <?= (int) $totalPages ?></span>
            <?php endif; ?>
        </div>

        <div class="table-scroll" tabindex="0" role="region" aria-label="All sacrament records; scroll horizontally to view all columns">
            <table class="admin-table unified-records-table">
                <thead>
                    <tr>
                        <th><a class="table-sort-link<?= $sort === 'book' ? ' is-active' : '' ?>" href="<?= e(unified_sort_url('book')) ?>">Book<?= unified_sort_indicator('book') ?></a></th>
                        <th><a class="table-sort-link<?= $sort === 'page' ? ' is-active' : '' ?>" href="<?= e(unified_sort_url('page')) ?>">Page<?= unified_sort_indicator('page') ?></a></th>
                        <th><a class="table-sort-link<?= $sort === 'line' ? ' is-active' : '' ?>" href="<?= e(unified_sort_url('line')) ?>">Line<?= unified_sort_indicator('line') ?></a></th>
                        <th><a class="table-sort-link<?= $sort === 'name' ? ' is-active' : '' ?>" href="<?= e(unified_sort_url('name')) ?>">Full Name<?= unified_sort_indicator('name') ?></a></th>
                        <th><a class="table-sort-link<?= in_array($sort, ['date_desc', 'date_asc'], true) ? ' is-active' : '' ?>" href="<?= e(unified_sort_url($sort === 'date_desc' ? 'date_asc' : 'date_desc')) ?>">Date<?= unified_sort_indicator($sort === 'date_desc' || $sort === 'date_asc' ? $sort : 'date_desc') ?></a></th>
                        <th>
                            <details class="table-filter-menu">
                                <summary class="table-filter-summary<?= $type !== '' ? ' is-active' : '' ?>">SACRAMENT <span class="table-filter-caret">▾</span></summary>
                                <form method="get" action="<?= e($basePath . '/admin/records/index.php') ?>" class="table-filter-form" autocomplete="off">
                                    <?php if ($search !== ''): ?><input type="hidden" name="q" value="<?= e($search) ?>"><?php endif; ?>
                                    <?php if ($fromYear !== null): ?><input type="hidden" name="from" value="<?= (int) $fromYear ?>"><?php endif; ?>
                                    <?php if ($toYear !== null): ?><input type="hidden" name="to" value="<?= (int) $toYear ?>"><?php endif; ?>
                                    <?php if ($perPage !== 25): ?><input type="hidden" name="per_page" value="<?= (int) $perPage ?>"><?php endif; ?>
                                    <?php if ($sort !== 'date_desc'): ?><input type="hidden" name="sort" value="<?= e($sort) ?>"><?php endif; ?>
                                    <select name="type" class="table-filter-select" onchange="this.form.submit()" aria-label="Sacrament">
                                        <option value="">All types</option>
                                        <?php foreach ($labels as $value => $label): ?>
                                            <option value="<?= e($value) ?>" <?= $type === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </form>
                            </details>
                        </th>
                        <th>Options</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!$records): ?>
                    <tr>
                        <td colspan="7" class="empty-table-row">
                            <div class="empty-state">
                                <h2>No register records found</h2>
                                <p>Try another part of the name, a broader search, sacrament type, or year range. To find a certificate request, open the Certificate Requests queue.</p>
                                <a class="btn btn-secondary btn-small" href="<?= e($basePath . '/admin/requests/queue.php') ?>">Open Certificate Requests</a>
                            </div>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($records as $record): ?>
                        <?php
                        $reference = $record['book_no'] !== null && $record['book_no'] !== ''
                            ? trim($record['book_no'] . ' / ' . $record['page_no'] . ' / ' . $record['line_no'], ' /')
                            : 'Not recorded';
                        $viewUrl = $basePath . '/admin/records/view.php?type=' . urlencode($record['record_type']) . '&id=' . (int) $record['id'] . '&return=' . urlencode($selfReturn);
                        $recordDisplayName = display_name_with_middle_initial(
                            (string) $record['record_name'],
                            isset($record['record_first_name']) ? (string) $record['record_first_name'] : null,
                            isset($record['record_middle_name']) ? (string) $record['record_middle_name'] : null,
                            isset($record['record_last_name']) ? (string) $record['record_last_name'] : null,
                            isset($record['record_suffix']) ? (string) $record['record_suffix'] : null
                        );
                        if ($record['record_type'] === 'marriage') {
                            $recordDisplayName .= ' & ' . display_name_with_middle_initial(
                                (string) $record['record_name'],
                                isset($record['spouse_first_name']) ? (string) $record['spouse_first_name'] : null,
                                isset($record['spouse_middle_name']) ? (string) $record['spouse_middle_name'] : null,
                                isset($record['spouse_last_name']) ? (string) $record['spouse_last_name'] : null,
                                isset($record['spouse_suffix']) ? (string) $record['spouse_suffix'] : null
                            );
                        }
                        ?>
                        <tr>
                            <td><?= e($record['book_no'] ?: '—') ?></td>
                            <td><?= e($record['page_no'] ?: '—') ?></td>
                            <td><?= e($record['line_no'] ?: '—') ?></td>
                            <td><strong><?php if (!empty($record['person_id'])): ?><a href="<?= e($basePath . '/admin/system/person-profile.php?id=' . (int) $record['person_id']) ?>"><?= e($recordDisplayName) ?></a><?php else: ?><?= e($recordDisplayName) ?><?php endif; ?></strong></td>
                            <td><?= $record['event_date'] ? e(date('M j, Y', strtotime($record['event_date']))) : '—' ?></td>
                            <td><span class="record-type-badge record-type-<?= e($record['record_type']) ?>"><?= e($labels[$record['record_type']]) ?></span></td>
                            <?php
                        $editorType = $editorTypeByRecordType[$record['record_type']] ?? null;
                        $editUrl = $editorType
                            ? $basePath . '/admin/records/editor.php?' . http_build_query(['type' => $editorType, 'edit' => (int) $record['id'], 'return' => $selfReturn])
                            : null;
                        ?>
                        <td class="row-actions">
                            <a class="btn btn-secondary btn-small" href="<?= e($viewUrl) ?>">View record</a>
                            <?php if ($editUrl): ?>
                                <a class="btn btn-secondary btn-small" href="<?= e($editUrl) ?>">Edit</a>
                            <?php endif; ?>
                        </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if ($totalPages > 1): ?>
            <nav class="record-pagination" aria-label="Record pages">
                <?php if ($page > 1): ?><a class="btn btn-secondary btn-small" href="<?= e(unified_records_url(['page' => $page - 1])) ?>">Previous</a><?php endif; ?>
                <span>Page <?= (int) $page ?> of <?= (int) $totalPages ?></span>
                <?php if ($page < $totalPages): ?><a class="btn btn-secondary btn-small" href="<?= e(unified_records_url(['page' => $page + 1])) ?>">Next</a><?php endif; ?>
            </nav>
        <?php endif; ?>
<?php require_once __DIR__ . '/../../includes/admin-footer.php'; ?>
