<?php
/**
 * =====================================================================
 * SRS-SPPO "HOW IT WORKS" (public explainer page)
 * =====================================================================
 * Purpose: Walks visitors through the parish's request workflow in
 *          six ledger-style steps, then offers two path cards that
 *          route them to the right entry point. Static content — no
 *          database queries.
 * =====================================================================
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

// Subfolder-safe URL prefix for the navigation links below.
$basePath = $basePath ?? base_path();

$pageTitle = 'How It Works';
require_once __DIR__ . '/../includes/header.php';
?>

<!-- Intro hero: frames the request workflow -->
<section class="workflow-hero">
<span class="eyebrow">How Online Intake Works</span>
    <h1>Convenient submission, careful parish review.</h1>
    <p>Send the details online first. The parish office will review them and tell you what to do next.</p>
</section>

<!-- Step-by-step ledger (one row per step) -->
<div class="ledger">

    <!-- Step 1: choose request type -->
    <div class="ledger-row">
        <span class="ledger-no"></span>
        <div>
<h3>Choose what you need</h3>
            <p>Choose a certificate if the sacrament already happened. Start a pre-application if you are preparing for Baptism, Confirmation, First Communion, or Marriage.</p>
        </div>
    </div>

    <!-- Step 2: provide known details -->
    <div class="ledger-row">
        <span class="ledger-no"></span>
        <div>
<h3>Send your request</h3>
            <p>Enter the details requested by the form. You do not need an account. Do not upload or send personal documents with the form.</p>
        </div>
    </div>

    <!-- Step 3: staff verification -->
    <div class="ledger-row">
        <span class="ledger-no"></span>
        <div>
<h3>Secretary review</h3>
            <p>The parish office checks the details against its records and confirms any requirements. Sending a form does not mean it is approved.</p>
        </div>
    </div>

    <!-- Step 4: payment (before processing; made outside the system) -->
    <div class="ledger-row">
        <span class="ledger-no"></span>
        <div>
<h3>If payment is needed</h3>
            <p>Payment is not taken on this website. If payment is needed, the parish office will tell you the amount and how to pay. Processing continues after the office records payment.</p>
        </div>
    </div>

    <!-- Step 5: notification -->
    <div class="ledger-row">
        <span class="ledger-no"></span>
        <div>
<h3>Receive updates from the parish office</h3>
            <p>The Parish Office may email you about missing information and pickup. Use your person reference and the email address used on a request to see statuses for linked applications and certificate requests.</p>
        </div>
    </div>

    <!-- Step 6: pickup (identity verified here — no online uploads) -->
    <div class="ledger-row">
        <span class="ledger-no"></span>
        <div>
<h3>Finish at the parish office</h3>
            <p>If documents are needed, the parish office will tell you what to bring. Use your existing person reference and contact the office about the same pending application instead of submitting it again. Certificates are collected at the Parish Office; they are not issued online.</p>
        </div>
    </div>

</div>

<!-- Two service paths: pick the flow that matches the visitor's need -->
<div class="path-cards">
    <div class="path-card">
        <h3>Sacrament Pre-Application</h3>
        <p>Preparing for Baptism, First Communion, Confirmation, or a church wedding? Start a pre-application for parish-office review.</p>
        <a href="<?= e($basePath) ?>/public/services.php#sacrament-applications" class="btn btn-secondary">Start a Pre-Application</a>
    </div>
    <div class="path-card">
        <h3>Certificate Request</h3>
        <p>Need proof of a sacrament that already took place? Request a certified copy.</p>
        <a href="<?= e($basePath) ?>/public/services.php#certificate-requests" class="btn btn-secondary">Request a Certificate</a>
    </div>
</div>

<!-- Final calls-to-action -->
<div class="workflow-cta">
    <p>After you submit a certificate request or sacrament pre-application, the Parish Office may email you with an update. The same person reference is used for requests linked to your profile; use it with the email address on a request to view linked statuses.</p>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
